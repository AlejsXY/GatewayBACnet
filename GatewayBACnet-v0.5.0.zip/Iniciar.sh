#!/bin/bash
cd "$(dirname "$0")"
java -cp "GatewayBACnet.jar:lib/*" com.mycompany.servidormodbusTest.GatewayGUI
