@echo off
cd /d "%~dp0"
java -cp "GatewayBACnet.jar;lib/*" com.mycompany.servidormodbusTest.GatewayGUI
pause
